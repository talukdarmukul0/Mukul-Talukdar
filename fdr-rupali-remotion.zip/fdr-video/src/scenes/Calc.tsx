import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { sceneStarts as S, taka, bn, periods, PRINCIPAL, EXCISE } from "../data";
import { Card, Counter, Entrance, H1, Body, Pill, SceneShell, useCue } from "../common";

const C = theme.colors;
type P = typeof periods.m3;
type Cues = { gross: number; t15: number; ex: number; net15: number; total15?: number; t10: number; net10: number; total10?: number; end: number };

// Cue times (s) come straight from Voice_Over.srt.
export const cues: Record<"m3" | "m6" | "y1", Cues> = {
  m3: { gross: 62.0, t15: 67.5, ex: 72.4, net15: 74.6, t10: 77.0, net10: 82.2, end: 85.8 },
  m6: { gross: 87.3, t15: 93.0, ex: 97.0, net15: 98.8, t10: 101.7, net10: 105.6, end: 110.3 },
  y1: { gross: 113.0, t15: 117.0, ex: 119.1, net15: 121.2, total15: 122.8, t10: 126.9, net10: 131.2, total10: 134.4, end: 138.5 },
};

const Line: React.FC<{ label: string; value: number; delay: number; minus?: boolean; big?: boolean; hot?: boolean }> = ({ label, value, delay, minus, big, hot }) => (
  <Entrance delay={delay} y={26}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", padding: "8px 4px" }}>
      <span style={{ ...Body, fontSize: big ? 44 : 38, color: big ? C.text : C.textDim }}>{label}</span>
      <Counter to={value} delay={delay} decimals={Number.isInteger(value) ? 0 : 2} prefix={minus ? "− ৳ " : "৳ "}
        style={{ ...H1, fontSize: big ? 78 : 50, color: hot ? C.primary : minus ? C.danger : C.text }} />
    </div>
  </Entrance>
);

const Column: React.FC<{ title: string; hint: string; tax: number; taxLabel: string; net: number; total?: number; tCue: number; exCue?: number; nCue: number; totCue?: number; at: (s: number) => number; hotNet: boolean; hotTotal: boolean }> =
  ({ title, hint, tax, taxLabel, net, total, tCue, exCue, nCue, totCue, at, hotNet, hotTotal }) => (
    <Card style={{ width: 800, padding: "22px 40px" }}>
      <Entrance delay={at(tCue - 0.6)} y={16}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", borderBottom: `1px solid ${C.cardBorder}`, paddingBottom: 8 }}>
          <span style={{ ...H1, fontSize: 48 }}>{title}</span><span style={{ ...Body, fontSize: 30 }}>{hint}</span>
        </div>
      </Entrance>
      <Line label={taxLabel} value={tax} delay={at(tCue)} minus />
      <Line label="আবগারি শুল্ক" value={EXCISE} delay={at(exCue ?? tCue + 4.0)} minus />
      <div style={{ height: 1, background: C.cardBorder, margin: "6px 0" }} />
      <Line label="নিট মুনাফা" value={net} delay={at(nCue)} big hot={hotNet} />
      {total !== undefined && totCue !== undefined && <Line label="মেয়াদ শেষে মোট" value={total} delay={at(totCue)} big hot={hotTotal} />}
    </Card>
  );

export const Calc: React.FC<{ dur: number; id: "m3" | "m6" | "y1" }> = ({ dur, id }) => {
  const frame = useCurrentFrame();
  const p: P = periods[id];
  const k = cues[id];
  const at = useCue(S[id]);
  const hot15 = frame >= at(k.net15) && frame < at(k.t10 - 0.3);
  const hot10 = frame >= at(k.net10);
  return (
    <SceneShell dur={dur}>
      <AbsoluteFill style={{ alignItems: "center", paddingTop: 52, gap: 22, display: "flex", flexDirection: "column" }}>
        <Entrance delay={at(S[id] + 0.1)} y={30}>
          <div style={{ display: "flex", alignItems: "center", gap: 28 }}>
            <Pill hot style={{ fontSize: 60, padding: "6px 44px" }}>{p.label}</Pill>
            <span style={{ ...H1, fontSize: 60 }}>{bn(p.rate, 2)}% হারে</span>
            <span style={{ ...Body, fontSize: 38 }}>({taka(PRINCIPAL)})</span>
          </div>
        </Entrance>
        <Entrance delay={at(k.gross)} y={40}>
          <Card style={{ display: "flex", alignItems: "baseline", gap: 30, padding: "14px 50px" }}>
            <span style={{ ...Body, fontSize: 42 }}>মোট মুনাফা</span>
            <Counter to={p.gross} delay={at(k.gross)} prefix="৳ " style={{ ...H1, fontSize: 100, color: C.accent }} />
          </Card>
        </Entrance>
        <div style={{ display: "flex", gap: 40, marginTop: 6 }}>
          <Column title="সাধারণ" hint="১৫% উৎসে কর" taxLabel="উৎসে কর ১৫%" tax={p.t15} net={p.net15} total={k.total15 ? p.net15 + PRINCIPAL : undefined}
            tCue={k.t15} exCue={k.ex} nCue={k.net15} totCue={k.total15} at={at} hotNet={hot15 && !k.total15} hotTotal={hot15 && !!k.total15} />
          <Column title="রিটার্নদাতা" hint="১০% উৎসে কর" taxLabel="উৎসে কর ১০%" tax={p.t10} net={p.net10} total={k.total10 ? p.net10 + PRINCIPAL : undefined}
            tCue={k.t10} exCue={k.t10 + 1.8} nCue={k.net10} totCue={k.total10} at={at} hotNet={hot10 && !k.total10} hotTotal={hot10 && !!k.total10} />
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
