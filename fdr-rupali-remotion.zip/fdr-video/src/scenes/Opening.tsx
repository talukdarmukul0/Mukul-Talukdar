import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { sceneStarts as S, bn, periods } from "../data";
import { Breathe, Card, Counter, Entrance, H1, Body, IconBank, IconShield, Pill, SceneShell, useCue, WordReveal } from "../common";

const C = theme.colors;
const center: React.CSSProperties = { alignItems: "center", justifyContent: "center", display: "flex", flexDirection: "column" };

/* ---------------- 1. HOOK 0–9.3s ---------------- */
export const Hook: React.FC<{ dur: number }> = ({ dur }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const at = useCue(S.hook);
  const logo = spring({ frame: frame - at(0.2), fps, config: theme.spring.bouncy });
  const logoUp = interpolate(frame, [at(3.6), at(4.4)], [0, -300], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <SceneShell dur={dur}>
      <AbsoluteFill style={{ ...center, transform: `translateY(${logoUp}px) scale(${interpolate(frame, [at(3.6), at(4.4)], [1, 0.55], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" })})` }}>
        <div style={{ transform: `scale(${logo}) rotate(${(1 - logo) * -90}deg)`, filter: `drop-shadow(0 0 40px ${C.glow})` }}>
          <IconBank size={190} color={C.primary} />
        </div>
        <Entrance delay={at(1.27)} y={30}><h1 style={{ ...H1, fontSize: 104, marginTop: 20 }}>বাংলাদেশী ব্যাংক ইনফো</h1></Entrance>
        <Entrance delay={at(0.3)} y={20}><p style={{ ...Body, fontSize: 44 }}>আসসালামু আলাইকুম</p></Entrance>
      </AbsoluteFill>
      <AbsoluteFill style={{ ...center, paddingTop: 80 }}>
        <Entrance delay={at(3.95)} y={50}>
          <Breathe><div style={{ ...H1, fontSize: 210, color: C.text }}>
            <Counter to={500000} delay={at(3.95)} prefix="৳ " />
          </div></Breathe>
        </Entrance>
        <Entrance delay={at(4.3)} y={30}><p style={{ ...H1, fontSize: 60, fontWeight: 600 }}>আপনার কাছে কি ৫ লাখ টাকা আছে?</p></Entrance>
        <Entrance delay={at(6.05)} y={40} style={{ marginTop: 34 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
            <IconShield size={84} color={C.accent} />
            <WordReveal text="নিরাপদে রেখে নিশ্চিত মুনাফা" delay={at(6.05)} per={4} highlight={["নিশ্চিত", "মুনাফা"]} style={{ ...H1, fontSize: 72 }} />
          </div>
        </Entrance>
      </AbsoluteFill>
    </SceneShell>
  );
};

/* ---------------- 2. INTRO 9.3–23.7s ---------------- */
export const Intro: React.FC<{ dur: number }> = ({ dur }) => {
  const at = useCue(S.intro);
  const chips = [periods.m3, periods.m6, periods.y1];
  return (
    <SceneShell dur={dur}>
      <AbsoluteFill style={{ ...center, gap: 34, paddingBottom: 90 }}>
        <Entrance delay={at(9.6)}><Pill hot style={{ fontSize: 40 }}>নতুন সুদহার</Pill></Entrance>
        <Entrance delay={at(9.9)} y={50}><h1 style={{ ...H1, fontSize: 130 }}>রূপালী ব্যাংক পিএলসি</h1></Entrance>
        <Entrance delay={at(11.6)} y={30}><p style={{ ...H1, fontSize: 72, fontWeight: 600, color: C.textDim }}>এফডিআরের সুদহার নতুন করে নির্ধারণ</p></Entrance>
        <Entrance delay={at(14.5)} y={40} style={{ marginTop: 20 }}>
          <Card><span style={{ ...H1, fontSize: 64 }}>৫ লাখ টাকা রাখলে — </span><span style={{ ...H1, fontSize: 64, color: C.accent }}>ট্যাক্স ও উৎসে কর কাটার পর</span></Card>
        </Entrance>
        <div style={{ display: "flex", gap: 36, marginTop: 14 }}>
          {chips.map((p, i) => (
            <Entrance key={p.label} delay={at(18.5 + i * 1.3)} y={50}>
              <Breathe><Card style={{ minWidth: 330, textAlign: "center" }}><span style={{ ...H1, fontSize: 70 }}>{p.label}</span></Card></Breathe>
            </Entrance>
          ))}
        </div>
        <Entrance delay={at(21.7)} y={30}><p style={{ ...H1, fontSize: 70, color: C.primary }}>হাতে পাবেন কত টাকা?</p></Entrance>
      </AbsoluteFill>
    </SceneShell>
  );
};

/* ---------------- 3. CIRCULAR 23.7–47s ---------------- */
export const Circular: React.FC<{ dur: number }> = ({ dur }) => {
  const frame = useCurrentFrame();
  const at = useCue(S.circular);
  const rows = [
    { p: periods.m3, cue: 32.4 },
    { p: periods.m6, cue: 36.9 },
    { p: periods.y1, cue: 41.4 },
  ];
  const arrow = interpolate(frame, [at(28.7), at(29.4)], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <SceneShell dur={dur}>
      <AbsoluteFill style={{ ...center, justifyContent: "flex-start", paddingTop: 70, gap: 30 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 40 }}>
          <Entrance delay={at(24.0)} x={-60} y={0}><Card><p style={{ ...Body, fontSize: 34 }}>রূপালী ব্যাংক ট্রেজারি সার্কুলার</p><p style={{ ...H1, fontSize: 64 }}>৮ অক্টোবর ২০২৬</p></Card></Entrance>
          <div style={{ width: 150 * arrow, height: 6, borderRadius: 6, background: C.accent }} />
          <Entrance delay={at(28.9)} x={60} y={0}><Card hot={frame < at(32.4)}><p style={{ ...Body, fontSize: 34 }}>কার্যকর</p><p style={{ ...H1, fontSize: 64 }}>১১ অক্টোবর ২০২৬</p></Card></Entrance>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 20, marginTop: 30 }}>
          <Entrance delay={at(31.8)} y={20}>
            <div style={{ display: "grid", gridTemplateColumns: "300px 260px 120px 260px", ...Body, fontSize: 36, textAlign: "center" }}>
              <span>মেয়াদ</span><span>আগে</span><span /><span>এখন</span>
            </div>
          </Entrance>
          {rows.map(({ p, cue }) => {
            const strike = interpolate(frame, [at(cue + 0.9), at(cue + 1.3)], [0, 100], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
            return (
              <Entrance key={p.label} delay={at(cue)} y={40}>
                <Card hot={frame >= at(cue) && frame < at(cue + 4.2)} style={{ display: "grid", gridTemplateColumns: "300px 260px 120px 260px", alignItems: "center", textAlign: "center", padding: "14px 20px" }}>
                  <span style={{ ...H1, fontSize: 56 }}>{p.label}{p.months === 12 ? "+" : ""}</span>
                  <span style={{ position: "relative", ...H1, fontSize: 56, color: C.textDim }}>
                    {bn(p.oldRate, 2)}%
                    <span style={{ position: "absolute", left: "15%", top: "55%", height: 5, width: `${strike * 0.7}%`, background: C.danger, borderRadius: 4 }} />
                  </span>
                  <span style={{ ...H1, fontSize: 56, color: C.textDim }}>←</span>
                  <span style={{ ...H1, fontSize: 64, color: C.accent }}>{bn(p.rate, 2)}%</span>
                </Card>
              </Entrance>
            );
          })}
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};

/* ---------------- 4. TAX RULES 47–60.6s ---------------- */
export const Tax: React.FC<{ dur: number }> = ({ dur }) => {
  const frame = useCurrentFrame();
  const at = useCue(S.tax);
  const cards = [
    { big: "১৫%", small: "উৎসে কর", sub: "মুনাফার ওপর কাটা হয়", cue: 49.5, end: 52.4 },
    { big: "১০%", small: "উৎসে কর", sub: "আয়কর রিটার্ন দাখিল করলে", cue: 52.44, end: 56.4 },
    { big: "৳ ৫০০", small: "আবগারি শুল্ক", sub: "৫ লাখ টাকার এফডিআরে", cue: 56.5, end: 60 },
  ];
  return (
    <SceneShell dur={dur}>
      <AbsoluteFill style={{ ...center, gap: 50, paddingBottom: 90 }}>
        <Entrance delay={at(47.3)} y={30}><h1 style={{ ...H1, fontSize: 88 }}>হিসাবের আগে <span style={{ color: C.accent }}>কর কাটার নিয়ম</span></h1></Entrance>
        <div style={{ display: "flex", gap: 44 }}>
          {cards.map((c) => {
            const hot = frame >= at(c.cue) && frame < at(c.end);
            return (
              <Entrance key={c.big} delay={at(c.cue)} y={60}>
                <Card hot={hot} style={{ width: 520, textAlign: "center", padding: "44px 30px" }}>
                  <div style={{ ...H1, fontSize: 150, color: hot ? C.primary : C.text }}>{c.big}</div>
                  <div style={{ ...H1, fontSize: 52, fontWeight: 600 }}>{c.small}</div>
                  <div style={{ ...Body, fontSize: 36, marginTop: 8 }}>{c.sub}</div>
                </Card>
              </Entrance>
            );
          })}
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
