import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { sceneStarts as S, periods, bn, taka } from "../data";
import { Breathe, Card, Counter, Entrance, H1, Body, Pill, SceneShell, useCue,
  IconBank, IconBell, IconComment, IconId, IconLike, IconLock, IconPhoto, IconPlay, IconShare } from "../common";

const C = theme.colors;
const col: React.CSSProperties = { alignItems: "center", display: "flex", flexDirection: "column" };
const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/* ---------------- SUMMARY 138.5–150.2s ---------------- */
export const Summary: React.FC<{ dur: number }> = ({ dur }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const at = useCue(S.summary);
  const MAX = 35500, H = 400;
  const groups = [periods.m3, periods.m6, periods.y1];
  const diffs = groups.map((g) => g.net10 - g.net15);
  const focus = frame >= at(147.1);
  return (
    <SceneShell dur={dur}>
      <AbsoluteFill style={{ ...col, justifyContent: "flex-start", paddingTop: 60, gap: 14 }}>
        <Entrance delay={at(138.8)} y={30}><h1 style={{ ...H1, fontSize: 76 }}>নিট মুনাফা: <span style={{ color: C.accent }}>একনজরে</span></h1></Entrance>
        <div style={{ display: "flex", gap: 90, alignItems: "flex-end", height: H + 160, marginTop: 20 }}>
          {groups.map((g, gi) => {
            const isY = gi === 2;
            return (
              <div key={g.label} style={{ ...col, gap: 10 }}>
                <div style={{ display: "flex", gap: 22, alignItems: "flex-end", height: H + 70 }}>
                  {[{ v: g.net15, c: C.textDim, d: 0 }, { v: g.net10, c: isY && focus ? C.primary : C.accent, d: 4 }].map((b, bi) => {
                    const pr = spring({ frame: frame - at(139.4 + gi * 1.6) - b.d, fps, config: theme.spring.smooth });
                    return (
                      <div key={bi} style={{ ...col, justifyContent: "flex-end", height: "100%" }}>
                        <div style={{ ...H1, fontSize: 34, opacity: pr, marginBottom: 6 }}>{taka(b.v)}</div>
                        <div style={{ width: 150, height: (b.v / MAX) * H * pr, background: b.c, borderRadius: "18px 18px 6px 6px",
                          boxShadow: isY && focus && bi === 1 ? `0 0 60px ${C.primary}66` : "none" }} />
                      </div>
                    );
                  })}
                </div>
                <div style={{ ...H1, fontSize: 52 }}>{g.label}</div>
                <Entrance delay={at(142.6 + gi * 1.2)} y={20}><div style={{ ...Body, fontSize: 34 }}>+ {taka(diffs[gi])} বেশি</div></Entrance>
              </div>
            );
          })}
        </div>
        <div style={{ display: "flex", gap: 40, marginTop: 4 }}>
          <Entrance delay={at(139.0)}><span style={{ ...Body, fontSize: 32 }}>▮ সাধারণ (১৫%)</span></Entrance>
          <Entrance delay={at(139.2)}><span style={{ ...Body, fontSize: 32, color: C.accent }}>▮ রিটার্নদাতা (১০%)</span></Entrance>
        </div>
        <Entrance delay={at(147.2)} y={40}>
          <Breathe><Pill hot style={{ fontSize: 56, padding: "8px 50px" }}>১ বছরে ব্যবধান <Counter to={2000} delay={at(147.2)} prefix="৳ " /></Pill></Breathe>
        </Entrance>
      </AbsoluteFill>
    </SceneShell>
  );
};

/* ---------------- DOCS 150.2–168s ---------------- */
const Doc: React.FC<{ Icon: React.FC<{ size?: number; color?: string }>; text: string; delay: number }> = ({ Icon, text, delay }) => (
  <Entrance delay={delay} y={34}>
    <Card style={{ display: "flex", alignItems: "center", gap: 26, padding: "20px 34px", width: 760 }}>
      <Icon size={74} color={C.accent} /><span style={{ ...H1, fontSize: 46, fontWeight: 600 }}>{text}</span>
    </Card>
  </Entrance>
);
export const Docs: React.FC<{ dur: number }> = ({ dur }) => {
  const at = useCue(S.docs);
  return (
    <SceneShell dur={dur}>
      <AbsoluteFill style={{ ...col, justifyContent: "flex-start", paddingTop: 60, gap: 22 }}>
        <Entrance delay={at(150.4)} y={30}><h1 style={{ ...H1, fontSize: 80 }}>এফডিআর খুলতে <span style={{ color: C.primary }}>কী কী কাগজ</span> লাগবে?</h1></Entrance>
        <div style={{ display: "flex", gap: 50, marginTop: 20 }}>
          <div style={{ ...col, gap: 20 }}>
            <Entrance delay={at(152.4)}><Pill style={{ fontSize: 46 }}>অ্যাকাউন্টধারী</Pill></Entrance>
            <Doc Icon={IconPhoto} text="২ কপি ছবি" delay={at(153.4)} />
            <Doc Icon={IconId} text="NID-র ১ কপি ফটোকপি" delay={at(155.6)} />
          </div>
          <div style={{ ...col, gap: 20 }}>
            <Entrance delay={at(158.7)}><Pill style={{ fontSize: 46 }}>নমিনি</Pill></Entrance>
            <Doc Icon={IconPhoto} text="১ কপি ছবি" delay={at(159.8)} />
            <Doc Icon={IconId} text="NID-র ফটোকপি" delay={at(161.6)} />
          </div>
        </div>
        <Entrance delay={at(164.1)} y={40} style={{ marginTop: 20 }}>
          <Breathe><Pill hot style={{ fontSize: 50, display: "flex", alignItems: "center", gap: 20 }}><IconBank size={58} color={theme.colors.bg} />নিকটস্থ রূপালী ব্যাংক শাখা</Pill></Breathe>
        </Entrance>
      </AbsoluteFill>
    </SceneShell>
  );
};

/* ---------------- LOAN 168–185.4s ---------------- */
export const Loan: React.FC<{ dur: number }> = ({ dur }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const at = useCue(S.loan);
  const ring = spring({ frame: frame - at(172.0), fps, config: theme.spring.smooth });
  const R = 150, CIRC = 2 * Math.PI * R;
  const bar = spring({ frame: frame - at(181.8), fps, config: theme.spring.smooth });
  return (
    <SceneShell dur={dur}>
      <AbsoluteFill style={{ ...col, justifyContent: "flex-start", paddingTop: 60, gap: 18 }}>
        <Entrance delay={at(168.3)} y={30}><h1 style={{ ...H1, fontSize: 84 }}>এফডিআরের আরেক সুবিধা: <span style={{ color: C.accent }}>ঋণ</span></h1></Entrance>
        <div style={{ display: "flex", alignItems: "center", gap: 90, marginTop: 20 }}>
          <Breathe>
            <div style={{ position: "relative", width: 380, height: 380 }}>
              <svg width={380} height={380} viewBox="0 0 380 380" style={{ transform: "rotate(-90deg)" }}>
                <circle cx={190} cy={190} r={R} fill="none" stroke={C.cardBorder} strokeWidth={34} />
                <circle cx={190} cy={190} r={R} fill="none" stroke={C.primary} strokeWidth={34} strokeLinecap="round"
                  strokeDasharray={CIRC} strokeDashoffset={CIRC * (1 - 0.8 * ring)} />
              </svg>
              <div style={{ position: "absolute", inset: 0, ...col, justifyContent: "center" }}>
                <span style={{ ...H1, fontSize: 120 }}><Counter to={80} delay={at(172.0)} suffix="%" /></span>
                <span style={{ ...Body, fontSize: 34 }}>পর্যন্ত ঋণ</span>
              </div>
            </div>
          </Breathe>
          <div style={{ ...col, alignItems: "flex-start", gap: 22 }}>
            <Entrance delay={at(173.2)} x={50} y={0}><Card><span style={{ ...H1, fontSize: 48 }}>এফডিআরের টাকার ৮০%</span></Card></Entrance>
            <Entrance delay={at(175.6)} x={50} y={0}><Card><span style={{ ...H1, fontSize: 48 }}>যেকোনো সময়</span></Card></Entrance>
            <Entrance delay={at(177.2)} x={50} y={0}><Card><span style={{ ...H1, fontSize: 48 }}>স্বল্প সময়ের জন্য</span></Card></Entrance>
          </div>
        </div>
        <Entrance delay={at(181.7)} y={40} style={{ marginTop: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 30 }}>
            <span style={{ ...H1, fontSize: 56 }}>{taka(500000)}</span>
            <div style={{ width: 520, height: 46, borderRadius: 24, background: C.card, border: `1.5px solid ${C.cardBorder}`, overflow: "hidden" }}>
              <div style={{ width: `${80 * bar}%`, height: "100%", background: C.accent, borderRadius: 24 }} />
            </div>
            <span style={{ ...H1, fontSize: 56, color: C.accent }}>→ {taka(400000)}</span>
          </div>
        </Entrance>
        <Entrance delay={at(184.6)} y={20}><div style={{ display: "flex", alignItems: "center", gap: 16 }}><IconLock size={52} color={C.textDim} /><span style={{ ...Body, fontSize: 40 }}>এফডিআর না ভেঙেই</span></div></Entrance>
      </AbsoluteFill>
    </SceneShell>
  );
};

/* ---------------- OUTRO 185.4–204.6s ---------------- */
export const Outro: React.FC<{ dur: number }> = ({ dur }) => {
  const frame = useCurrentFrame();
  const at = useCue(S.outro);
  const ring = Math.sin(frame / 4) * 12;
  const cta = [
    { Icon: IconLike, label: "লাইক", cue: 193.3 },
    { Icon: IconShare, label: "শেয়ার", cue: 194.3 },
    { Icon: IconPlay, label: "সাবস্ক্রাইব", cue: 195.4 },
    { Icon: IconBell, label: "বেল আইকন", cue: 197.1 },
    { Icon: IconComment, label: "কমেন্ট", cue: 199.4 },
  ];
  const showCta = frame >= at(193.0);
  return (
    <SceneShell dur={dur}>
      <AbsoluteFill style={{ ...col, justifyContent: "center", gap: 36, paddingBottom: 70 }}>
        {!showCta && (
          <>
            <Entrance delay={at(185.6)} y={40}><h1 style={{ ...H1, fontSize: 88 }}>৫ লাখ টাকার এফডিআর — <span style={{ color: C.accent }}>পুরো হিসাব</span></h1></Entrance>
            <div style={{ display: "flex", gap: 34 }}>
              {[periods.m3, periods.m6, periods.y1].map((p, i) => (
                <Entrance key={p.label} delay={at(187.0 + i * 0.5)} y={40}>
                  <Card style={{ textAlign: "center", minWidth: 430 }}>
                    <div style={{ ...H1, fontSize: 50 }}>{p.label}</div>
                    <div style={{ ...Body, fontSize: 30 }}>নিট মুনাফা (রিটার্নদাতা)</div>
                    <div style={{ ...H1, fontSize: 60, color: C.accent }}>{taka(p.net10)}</div>
                  </Card>
                </Entrance>
              ))}
            </div>
            <Entrance delay={at(189.5)} y={30}><p style={{ ...Body, fontSize: 40 }}>বিস্তারিত ও সর্বশেষ তথ্যের জন্য ব্যাংকের শাখায় যোগাযোগ করুন</p></Entrance>
          </>
        )}
        {showCta && (
          <>
            <div style={{ display: "flex", gap: 44 }}>
              {cta.map(({ Icon, label, cue }) => {
                const hot = frame >= at(cue) && frame < at(cue + 1.6);
                return (
                  <Entrance key={label} delay={at(cue)} y={50}>
                    <div style={{ ...col, gap: 12 }}>
                      <div style={{ width: 170, height: 170, borderRadius: 44, background: hot ? C.primary : C.card, border: `1.5px solid ${hot ? C.primary : C.cardBorder}`,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        transform: label === "বেল আইকন" && hot ? `rotate(${ring}deg)` : undefined,
                        boxShadow: hot ? `0 0 60px ${C.primary}55` : "none" }}>
                        <Icon size={96} color={hot ? C.bg : C.text} />
                      </div>
                      <span style={{ ...H1, fontSize: 38 }}>{label}</span>
                    </div>
                  </Entrance>
                );
              })}
            </div>
            <Entrance delay={at(202.6)} y={40}><Breathe><h1 style={{ ...H1, fontSize: 84 }}>সবাই ভালো থাকবেন — <span style={{ color: C.primary }}>আল্লাহ্ হাফেজ</span></h1></Breathe></Entrance>
          </>
        )}
      </AbsoluteFill>
    </SceneShell>
  );
};
