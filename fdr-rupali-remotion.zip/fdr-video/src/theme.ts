// theme.ts — single source of truth. No inline colors/easings in components.
import { Easing } from "remotion";

export const theme = {
  colors: {
    bg: "#06130F",
    bgAlt: "#0C1F19",
    primary: "#F5B93B", // HERO (gold) — max one element per frame
    accent: "#2DD4A0",  // emerald
    danger: "#F87171",
    text: "#F3F7F5",
    textDim: "#9DB5AB",
    card: "rgba(255,255,255,0.05)",
    cardBorder: "rgba(255,255,255,0.10)",
    glow: "rgba(245,185,59,0.40)",
  },
  fonts: {
    display: '"Hind Siliguri", "Noto Sans Bengali", sans-serif',
    body: '"Noto Sans Bengali", "Hind Siliguri", sans-serif',
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;
