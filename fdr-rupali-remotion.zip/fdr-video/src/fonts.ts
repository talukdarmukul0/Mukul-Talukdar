import { loadFont as loadHind } from "@remotion/google-fonts/HindSiliguri";
import { loadFont as loadNoto } from "@remotion/google-fonts/NotoSansBengali";
loadHind("normal", { weights: ["500", "600", "700"], subsets: ["bengali", "latin"] });
loadNoto("normal", { weights: ["400", "500", "600"], subsets: ["bengali", "latin"] });
