import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { captions } from "./captionsData";
import { theme } from "./theme";

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  const cue = captions.find((c) => t >= c.from && t < c.to + 0.08);
  if (!cue) return null;
  const local = frame - Math.round(cue.from * fps);
  const p = spring({ frame: local, fps, config: theme.spring.snappy });
  const out = interpolate(t, [cue.to - 0.1, cue.to + 0.06], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <div style={{ position: "absolute", left: 0, right: 0, bottom: 56, display: "flex", justifyContent: "center", opacity: p * out,
      transform: `translateY(${(1 - p) * 16}px)` }}>
      <div style={{ fontFamily: theme.fonts.display, fontWeight: 600, fontSize: 40, color: theme.colors.text, lineHeight: 1.4,
        background: "rgba(0,0,0,0.45)", padding: "8px 30px", borderRadius: 18, maxWidth: 1500, textAlign: "center" }}>
        {cue.text}
      </div>
    </div>
  );
};
