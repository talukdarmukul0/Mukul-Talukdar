import React from "react";
import { AbsoluteFill, Audio, Composition, Sequence, staticFile } from "remotion";
import "./fonts";
import { FPS, TOTAL_FRAMES, SHOW_CAPTIONS, sceneStarts as S, popCues } from "./data";
import { BgMesh, Grade, Grain, Vignette } from "./common";
import { Captions } from "./Captions";
import { Hook, Intro, Circular, Tax } from "./scenes/Opening";
import { Calc } from "./scenes/Calc";
import { Summary, Docs, Loan, Outro } from "./scenes/Closing";

const f = (s: number) => Math.round(s * FPS);

const order = [
  ["hook", "intro"], ["intro", "circular"], ["circular", "tax"], ["tax", "m3"], ["m3", "m6"],
  ["m6", "y1"], ["y1", "summary"], ["summary", "docs"], ["docs", "loan"], ["loan", "outro"], ["outro", "end"],
] as const;

const render = (key: string, dur: number) => {
  switch (key) {
    case "hook": return <Hook dur={dur} />;
    case "intro": return <Intro dur={dur} />;
    case "circular": return <Circular dur={dur} />;
    case "tax": return <Tax dur={dur} />;
    case "m3": case "m6": case "y1": return <Calc dur={dur} id={key} />;
    case "summary": return <Summary dur={dur} />;
    case "docs": return <Docs dur={dur} />;
    case "loan": return <Loan dur={dur} />;
    default: return <Outro dur={dur} />;
  }
};

const Main: React.FC = () => (
  <AbsoluteFill>
    {/* layer 1: background mesh */}
    <BgMesh />
    {/* layers 2–3: scenes (assets + graphics + type) */}
    {order.map(([a, b]) => {
      const from = f(S[a]), dur = f(S[b]) - from;
      return <Sequence key={a} from={from} durationInFrames={dur}>{render(a, dur)}</Sequence>;
    })}
    {SHOW_CAPTIONS && <Captions />}
    {/* layer 4: grade, layer 5: grain + vignette */}
    <Grade /><Grain /><Vignette />
    {/* audio: voice-over + synthesized SFX */}
    <Audio src={staticFile("Voice_Over.mp3")} volume={1} />
    {Object.values(S).slice(1, -1).map((t) => (
      <Sequence key={`w${t}`} from={Math.max(0, f(t) - 4)}><Audio src={staticFile("sfx/whoosh.wav")} volume={0.25} /></Sequence>
    ))}
    {popCues.map((t) => (
      <Sequence key={`p${t}`} from={Math.max(0, f(t) - 2)}><Audio src={staticFile("sfx/pop.wav")} volume={0.2} /></Sequence>
    ))}
  </AbsoluteFill>
);

export const Root: React.FC = () => (
  <Composition id="FDR" component={Main} durationInFrames={TOTAL_FRAMES} fps={FPS} width={1920} height={1080} />
);
