// All numbers + timings (seconds, from Voice_Over.srt) live here.
export const FPS = 30;
export const DURATION_SEC = 204.591;
export const TOTAL_FRAMES = Math.round(DURATION_SEC * FPS); // 6138
export const SHOW_CAPTIONS = true;

export const PRINCIPAL = 500000;
export const EXCISE = 500;

// Bengali number formatting (lakh grouping: ৫,০০,০০০)
export const bn = (n: number, d = 0) =>
  new Intl.NumberFormat("bn-BD", { minimumFractionDigits: d, maximumFractionDigits: d }).format(n);
export const taka = (n: number) => "৳ " + bn(n, Number.isInteger(n) ? 0 : 2);

export const calc = (rate: number, months: number) => {
  const gross = (PRINCIPAL * rate * months) / 1200;
  const t15 = gross * 0.15;
  const t10 = gross * 0.1;
  return { gross, t15, t10, net15: gross - t15 - EXCISE, net10: gross - t10 - EXCISE };
};

export const periods = {
  m3: { label: "৩ মাস", months: 3, oldRate: 8, rate: 7.5, ...calc(7.5, 3) },
  m6: { label: "৬ মাস", months: 6, oldRate: 8.25, rate: 7.75, ...calc(7.75, 6) },
  y1: { label: "১ বছর", months: 12, oldRate: 8.5, rate: 8, ...calc(8, 12) },
};

// Scene start times (s). Each scene runs until the next one starts.
export const sceneStarts = {
  hook: 0,
  intro: 9.3,
  circular: 23.7,
  tax: 47.0,
  m3: 60.6,
  m6: 85.8,
  y1: 110.3,
  summary: 138.5,
  docs: 150.2,
  loan: 168.0,
  outro: 185.4,
  end: DURATION_SEC,
};

// SFX cue times (s) — whoosh at scene cuts, pop on key reveals
export const popCues = [
  4.0, 6.1, 24.0, 28.9, 32.4, 36.9, 41.4, 49.5, 52.5, 56.5,
  62.0, 67.5, 72.4, 74.6, 77.0, 82.2,
  87.3, 93.0, 97.0, 98.8, 101.7, 105.6,
  113.0, 117.0, 119.1, 121.2, 122.8, 126.9, 131.2, 134.4,
  147.2, 152.6, 158.8, 172.0, 181.8,
];
