import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "./theme";
import { bn } from "./data";

const C = theme.colors;
const clampOpts = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** Cue helper: seconds (absolute, from SRT) -> local frame inside a scene. */
export const useCue = (sceneStart: number) => {
  const { fps } = useVideoConfig();
  return (sec: number) => Math.round((sec - sceneStart) * fps);
};

// ---------- 5-layer stack pieces ----------
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60, d2 = Math.cos(frame / 70) * 50;
  return (
    <AbsoluteFill style={{ background: C.bg }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -560, left: -320 + d1,
        filter: "blur(60px)", background: `radial-gradient(circle, ${C.accent}2E, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1000, height: 1000, borderRadius: "50%", bottom: -480, right: -260 - d2,
        filter: "blur(80px)", background: `radial-gradient(circle, ${C.primary}24, transparent 65%)` }} />
    </AbsoluteFill>
  );
};
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: C.accent, mixBlendMode: "soft-light", opacity: 0.16 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 28%, transparent 72%, rgba(0,0,0,0.22))" }} />
  </AbsoluteFill>
);
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px",
    backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.06, mixBlendMode: "overlay" }} />;
};
export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.35) 100%)" }} />
);

// ---------- motion primitives ----------
export const Entrance: React.FC<{ delay?: number; y?: number; x?: number; children: React.ReactNode; style?: React.CSSProperties }> =
  ({ delay = 0, y = 40, x = 0, children, style }) => {
    const frame = useCurrentFrame();
    const { fps } = useVideoConfig();
    const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
    return (
      <div style={{ opacity: p, transform: `translate(${(1 - p) * x}px, ${(1 - p) * y}px) scale(${0.94 + 0.06 * p})`, ...style }}>
        {children}
      </div>
    );
  };

export const Breathe: React.FC<{ children: React.ReactNode; amp?: number; style?: React.CSSProperties }> = ({ children, amp = 0.012, style }) => {
  const frame = useCurrentFrame();
  return <div style={{ transform: `scale(${1 + Math.sin(frame / 22) * amp}) translateY(${Math.sin(frame / 30) * 3}px)`, ...style }}>{children}</div>;
};

export const SceneShell: React.FC<{ dur: number; children: React.ReactNode }> = ({ dur, children }) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [dur - 10, dur - 1], [1, 0], { easing: theme.ease.in, ...clampOpts });
  const y = interpolate(frame, [dur - 10, dur - 1], [0, -36], { easing: theme.ease.in, ...clampOpts });
  return <AbsoluteFill style={{ opacity: o, transform: `translateY(${y}px)` }}>{children}</AbsoluteFill>;
};

export const WordReveal: React.FC<{ text: string; delay?: number; per?: number; style?: React.CSSProperties; highlight?: string[] }> =
  ({ text, delay = 0, per = 3, style, highlight = [] }) => {
    const frame = useCurrentFrame();
    const { fps } = useVideoConfig();
    return (
      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: 18, ...style }}>
        {text.split(" ").map((w, i) => {
          const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
          return <span key={i} style={{ display: "inline-block", opacity: p, transform: `translateY(${(1 - p) * 30}px)`,
            color: highlight.includes(w) ? C.primary : undefined }}>{w}</span>;
        })}
      </div>
    );
  };

export const Counter: React.FC<{ to: number; delay?: number; decimals?: number; prefix?: string; suffix?: string; style?: React.CSSProperties }> =
  ({ to, delay = 0, decimals = 0, prefix = "", suffix = "", style }) => {
    const frame = useCurrentFrame();
    const { fps } = useVideoConfig();
    const p = spring({ frame: frame - delay, fps, config: { damping: 30, stiffness: 60 } });
    const v = interpolate(p, [0, 1], [0, to]);
    const shown = frame - delay < 0 ? 0 : v;
    return <span style={{ fontVariantNumeric: "tabular-nums", ...style }}>{prefix}{bn(shown, decimals)}{suffix}</span>;
  };

// ---------- type + surfaces ----------
export const H1: React.CSSProperties = { fontFamily: theme.fonts.display, fontWeight: 700, color: C.text, lineHeight: 1.3, margin: 0 };
export const Body: React.CSSProperties = { fontFamily: theme.fonts.body, fontWeight: 500, color: C.textDim, lineHeight: 1.5, margin: 0 };

export const Card: React.FC<{ children: React.ReactNode; hot?: boolean; style?: React.CSSProperties }> = ({ children, hot, style }) => (
  <div style={{ background: C.card, border: `1.5px solid ${hot ? C.primary : C.cardBorder}`, borderRadius: 32, padding: "28px 36px",
    boxShadow: hot ? `0 0 60px ${C.primary}44, 0 30px 60px -20px rgba(0,0,0,0.6)` : "0 30px 60px -20px rgba(0,0,0,0.6)", ...style }}>
    {children}
  </div>
);

export const Pill: React.FC<{ children: React.ReactNode; hot?: boolean; style?: React.CSSProperties }> = ({ children, hot, style }) => (
  <div style={{ ...H1, fontSize: 44, padding: "10px 34px", borderRadius: 999, background: hot ? C.primary : C.card,
    color: hot ? C.bg : C.text, border: `1.5px solid ${hot ? C.primary : C.cardBorder}`, ...style }}>{children}</div>
);

// ---------- simple SVG icons (theme colors, no emoji) ----------
type IconProps = { size?: number; color?: string };
const Svg: React.FC<IconProps & { children: React.ReactNode }> = ({ size = 80, color = C.text, children }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round">{children}</svg>
);
export const IconShield: React.FC<IconProps> = (p) => <Svg {...p}><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z" /><path d="M8.5 12l2.5 2.5 4.5-5" /></Svg>;
export const IconPhoto: React.FC<IconProps> = (p) => <Svg {...p}><rect x="3" y="4" width="18" height="16" rx="3" /><circle cx="9" cy="10" r="2" /><path d="M21 16l-5-5-8 9" /></Svg>;
export const IconId: React.FC<IconProps> = (p) => <Svg {...p}><rect x="2.5" y="5" width="19" height="14" rx="3" /><circle cx="8.5" cy="11" r="2" /><path d="M5.5 16c.8-1.8 4.2-1.8 5 0M14 10h5M14 14h4" /></Svg>;
export const IconBank: React.FC<IconProps> = (p) => <Svg {...p}><path d="M3 9l9-5 9 5M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 20h18" /></Svg>;
export const IconLock: React.FC<IconProps> = (p) => <Svg {...p}><rect x="5" y="11" width="14" height="9" rx="2.5" /><path d="M8 11V8a4 4 0 018 0v3" /></Svg>;
export const IconLike: React.FC<IconProps> = (p) => <Svg {...p}><path d="M7 11v9H4v-9zM7 11l4-8c2 0 3 1.5 2.5 3.5L13 9h5.5a2 2 0 012 2.4l-1.3 6.5a2 2 0 01-2 1.6H7" /></Svg>;
export const IconShare: React.FC<IconProps> = (p) => <Svg {...p}><circle cx="6" cy="12" r="2.5" /><circle cx="18" cy="6" r="2.5" /><circle cx="18" cy="18" r="2.5" /><path d="M8.2 10.8l7.6-3.6M8.2 13.2l7.6 3.6" /></Svg>;
export const IconBell: React.FC<IconProps> = (p) => <Svg {...p}><path d="M6 16V11a6 6 0 0112 0v5l1.5 2h-15zM10 21h4" /></Svg>;
export const IconComment: React.FC<IconProps> = (p) => <Svg {...p}><path d="M4 5h16v11H9l-5 4z" /><path d="M8 9.5h8M8 12.5h5" /></Svg>;
export const IconPlay: React.FC<IconProps> = (p) => <Svg {...p}><rect x="2.5" y="5" width="19" height="14" rx="4" /><path d="M10 9l5 3-5 3z" /></Svg>;
