import fs from "fs";
const raw = fs.readFileSync("public/Voice_Over.srt", "utf8").replace(/\r/g, "").trim().split(/\n\n+/);
const toSec = (s) => { const [h, m, r] = s.split(":"); const [sec, ms] = r.split(","); return +h * 3600 + +m * 60 + +sec + +ms / 1000; };
const cues = raw.map((b) => { const l = b.split("\n"); const [a, z] = l[1].split(" --> "); return { from: toSec(a), to: toSec(z), text: l.slice(2).join(" ") }; });
fs.writeFileSync("src/captionsData.ts", "// AUTO-GENERATED from Voice_Over.srt — run: node scripts/srt-to-ts.mjs\nexport const captions: {from:number;to:number;text:string}[] = " + JSON.stringify(cues, null, 1) + ";\n");
console.log(cues.length, "cues");
