import fs from "fs";
const SR = 44100;
const wav = (name, samples) => {
  const buf = Buffer.alloc(44 + samples.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + samples.length * 2, 4); buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22); buf.writeUInt32LE(SR, 24);
  buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write("data", 36);
  buf.writeUInt32LE(samples.length * 2, 40);
  samples.forEach((s, i) => buf.writeInt16LE(Math.max(-1, Math.min(1, s)) * 32767, 44 + i * 2));
  fs.writeFileSync(`public/sfx/${name}.wav`, buf);
};
{ const n = Math.floor(SR * 0.7), o = new Float32Array(n); let y = 0;
  for (let i = 0; i < n; i++) { const t = i / n; const env = Math.sin(Math.PI * t) ** 2; const a = 0.02 + 0.5 * Math.sin(Math.PI * t);
    y += a * ((Math.random() * 2 - 1) - y); o[i] = y * env * 1.6; } wav("whoosh", o); }
{ const n = Math.floor(SR * 0.25), o = new Float32Array(n); let ph = 0;
  for (let i = 0; i < n; i++) { const t = i / SR; const f = 150 + 650 * Math.exp(-t * 28); ph += 2 * Math.PI * f / SR; o[i] = Math.sin(ph) * Math.exp(-t * 16) * 0.8; } wav("pop", o); }
console.log("sfx ok");
